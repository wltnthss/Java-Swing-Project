package Log;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

public class LogFrame extends JFrame implements ActionListener{
	
	/** 1. 로그인창  **/	
	
	Container container = getContentPane();
		
	// 메인 상단 이미지
	static JPanel mainPhoto = new JPanel() {						
		Image photo = new ImageIcon("img/main.png").getImage();		
			@Override
			public void paint(Graphics g) {
				g.drawImage(photo, 0, 0, null);
			}
	};	
	
	// 메인 중단 컴포넌트
	JLabel labelId = new JLabel("아이디 : ", JLabel.RIGHT);					// 아이디 라벨
	JLabel labelPw = new JLabel("비밀번호 : ", JLabel.RIGHT);					// 패스워드 라벨
	
	JTextField tfid = new JTextField(15);									// 아이디 필드
	JPasswordField pfpw = new JPasswordField(15);							// 비밀번호 필드
		
	// 메인 하단 컴포넌트
	JButton buttonLogin = new JButton("로그인");								// 로그인 버튼
	JButton buttonRegister = new JButton("관리자가입");						// 회원가입 버튼
	
	public LogFrame() {
		setTitle("로그인");
		setSize(550, 400);
		setLocationRelativeTo(null);										// 로그인창 가운데 배치
		setResizable(false);												// 창 크기 조절 불가
		
		init();																// 화면 구성
		start();															// 동작 
		
		setVisible(true);
	}	
	private void init() {
		
		/** 1. 로그인창  **/	
		
		// 이미지 상대 위치
		mainPhoto.setLayout(null);
		mainPhoto.setBounds(0, 0, 550, 400);
		add(mainPhoto);	
		
		// 라벨, 텍스트 상대 위치
		labelId.setBounds(155, 260, 90, 30);
		add(labelId);
		labelPw.setBounds(155, 285, 90, 30);
		add(labelPw);
		
		tfid.setBounds(255, 266, 90, 20);
		add(tfid);
		pfpw.setBounds(255, 291, 90, 20);
		add(pfpw);	
		
		// 버튼 상대 위치		
		setLayout(null);
		buttonLogin.setBounds(180, 320, 90, 30);
		add(buttonLogin);
		buttonRegister.setBounds(270, 320, 90, 30);
		add(buttonRegister);	
				
		// 로그인창 디자인 구성 
		labelId.setFont(new Font("배달의민족 주아체", Font.BOLD, 15));
		labelPw.setFont(new Font("배달의민족 주아체", Font.BOLD, 15));		
		
		buttonLogin.setBorder(new BevelBorder(BevelBorder.RAISED));
		buttonLogin.setFont(new Font("배달의민족 주아체", Font.BOLD, 13));
		buttonRegister.setBorder(new BevelBorder(BevelBorder.RAISED));
		buttonRegister.setFont(new Font("배달의민족 주아체", Font.BOLD, 13));				
	}

	private void start() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		buttonLogin.addActionListener(this);
		buttonRegister.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// Login 버튼 설정		
		LogDAO dao = new LogDAO();
		int result = 0;
		
		if(e.getSource() == buttonLogin) {
						
			String id = tfid.getText();
			String pw = pfpw.getText();		
			
			result = dao.idpw(id, pw);
			
			if(result > 0) {
				JOptionPane.showMessageDialog(null, id + "님이 로그인 하셨습니다.");
				// 메인 화면 이동 명령어
			    new Swing_Member();
				dispose();
				//setDefaultCloseOperation(EXIT_ON_CLOSE);
			} else if (result < 0) {
				// 아이디, 패스워드 불일치 문구 생성
				if(!(id.equals("tfid.getText()") && pw.equals("pfpw.getText()"))) {
					tfid.setText("");
					pfpw.setText("");
					JOptionPane.showMessageDialog(null, "아이디 패스워드를 확인하세요");
				}				
//				// 아이디, 패스워드 미입력 문구 생성
//				if(id.equals("")) {
//					JOptionPane.showMessageDialog(null, "아이디를 입력해주세요");
//				} else if(pw.equals("")) {
//					JOptionPane.showMessageDialog(null, "비밀번호를 입력해주세요");
//				}
			}			
		}	
		// 회원가입 버튼 클릭
		if(e.getSource() == buttonRegister) {
			RegisterFrame rf = new RegisterFrame();
		}
	}		
}
