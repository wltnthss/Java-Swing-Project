package Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class TimeDAO {
   // 커넥션 설정
      String driver = "oracle.jdbc.driver.OracleDriver";
      String url = "jdbc:oracle:thin:@localhost:1521:xe";
      String user= "C##health";
      String password = "m1234";
      // 클래스 선언
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      
      // 1) OracleDriver 클래스 등록 확인
      public TimeDAO() {
         try {
            Class.forName(driver);
            //System.out.println("등록 성공");
         } catch (ClassNotFoundException e) {
            System.out.println("등록 실패");
            e.printStackTrace();
         }
      }
      // 2) DB 접속 함수
      public Connection getConnection() {
         try {
            conn = DriverManager.getConnection(url, user, password);
            //System.out.println("접속 성공");
         } catch (SQLException e) {
            System.out.println("접속 실패");
            e.printStackTrace();
         }
         return conn;
      }
      // 3) DB 접속 종료 함수 - 중복해서 쓰는 함수여서 함수로 만듦
      public void close() {
         try {
            if(rs != null) rs.close();
            if(pstmt != null) pstmt.close();
            if(conn != null) conn.close();
         } catch (SQLException e) {
            e.printStackTrace();
         }
      }
      // 4) insert 기능 함수
      public int insertArticle(TimeDTO dto) {
         // 함수에 진입했는지 test
         System.out.println("test");
         int result = 0;
         String sql = " insert into program values(?, ?, ?, ?, ?, ?)";
         
         conn = getConnection();
         try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, dto.getT_number());
            pstmt.setString(2, dto.getT_program());
            pstmt.setString(3, dto.getT_start());
            pstmt.setString(4, dto.getT_end());
            pstmt.setString(5, dto.getT_trainer());
            pstmt.setInt(6, dto.getT_max());
            result = pstmt.executeUpdate();
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         // result 값 확인해보기 - 오류 확인(블럭에 진입했는지 확인)
         //System.out.println("result = " + result);
         return result;
      }
      // 5) delete 기능 함수
      public int deleteArticle(String name) {
         // 함수에 진입했는지 test
         System.out.println("test");
         int result = 0;
         String sql = " delete school where name =?";
         
         conn = getConnection();
         try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            result = pstmt.executeUpdate();
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         // result 값 확인해보기 - 오류 확인(블럭에 진입했는지 확인)
         //System.out.println("result = " + result);
         return result;
      }
      // 6) select : 전체 검색
      public List<TimeDTO> selectList() {
         List<TimeDTO> list = new ArrayList<TimeDTO>();
         String sql = "select * from school";
         
         conn = getConnection();
         try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while(rs.next()) {   // 1개행 읽어오기
               int t_number = rs.getInt("t_number"); // 테이블 title 이름 - 대소문자 구분 없음
               String t_program  = rs.getString("t_program");
               String t_start  = rs.getString("t_start");
               String t_end  = rs.getString("t_end");
               String t_trainer  = rs.getString("t_trainer");
               int t_max = rs.getInt("t_max");
               TimeDTO dto = new TimeDTO(t_number,t_program,t_start, t_end, t_trainer,t_max);
               // 리스트에 저장
               list.add(dto);
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         return list;
      }
      // 7) select : 부분 검색
      public List<TimeDTO> selectPart(String name) {
         List<TimeDTO> list = new ArrayList<TimeDTO>();
         String sql = "select * from program where name like ?";
         
         conn = getConnection();
         try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + name + "%");
            rs = pstmt.executeQuery();
            while(rs.next()) {   // 1개행 읽어오기
               int t_number = rs.getInt("t_number"); // 테이블 title 이름 - 대소문자 구분 없음
               String t_program  = rs.getString("t_program");
               String t_start  = rs.getString("t_start");
               String t_end  = rs.getString("t_end");
               String t_trainer  = rs.getString("t_trainer");
               int t_max = rs.getInt("t_max");
               TimeDTO dto = new TimeDTO(t_number,t_program,t_start, t_end, t_trainer,t_max);
               // 리스트에 저장
               list.add(dto);
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         return list;
      }
      // 8) select : 1명 검색
      public TimeDTO selectOne(String name) {
         // 디버깅용
         // => 함수 (블록) 진입 확인
         System.out.println("test1");
         
         TimeDTO dto = new TimeDTO();
         String sql = "select * from school where name =?";
         
         conn = getConnection();
         // 디버깅용
         // => 코드 진행 확인
         System.out.println("test2");
         try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            if(rs.next()) {   // 1개행 읽어오기
               // 디버깅용
               // => 제어문 (블록) 진입 확인
               System.out.println("test3");
               
               int t_number = rs.getInt("t_number"); // 테이블 title 이름 - 대소문자 구분 없음
               String t_program  = rs.getString("t_program");
               String t_start  = rs.getString("t_start");
               String t_end  = rs.getString("t_end");
               String t_trainer  = rs.getString("t_trainer");
               int t_max = rs.getInt("t_max");
               dto = new TimeDTO(t_number,t_program,t_start, t_end, t_trainer,t_max);
               
            }
            // 디버깅용 : 
            // 1. 이 함수에 진입을 했는지 확인
            // 2. 여기까지 명령어가 진행되었는 지 확인
            // 3. 내가 원하는 값이 제대로 저장되었는지
            System.out.println("dto : " + dto.toString());
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         return dto;
      }
}