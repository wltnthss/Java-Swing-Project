package Log;

public class health {
	public static void main(String[] args) {
		new TimeFrame();
	}
}
