package Log;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;

import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.UtilDateModel;


class ProgramFrame extends JFrame implements ActionListener{
  
   Container container = getContentPane();
//   buttons.setPreferredSize(new Dimension(45, 28)); 인터넷 크기조절

   //오른쪽
   JPanel panelR = new JPanel();
   JPanel panelRR = new JPanel();
   JPanel panelRU = new JPanel();
   JButton button6 = new JButton("검색");                  //센터위 검색
   JButton button7 = new JButton("전체");                  //센터위 전체
     
//   String[]pname1= {"프로그램을 선택하세요","스피닝","요가"};
//   JComboBox<String>comboBox2 = new JComboBox<String>(pname1);   //센터프로그램명
     
   //왼쪽으로 몰아 넣기
   JPanel panelL = new JPanel();
   JLabel labelPname = new JLabel("프로그램명");
   JLabel labelPname1 = new JLabel("프로그램명");
   JLabel labelPweek = new JLabel("요일");
   JLabel labelPstart = new JLabel("시작일");
   JLabel labelPsend = new JLabel("종료일");
   JLabel labelPsmax = new JLabel("최대인원");
   ImageIcon imageIcon1 = new ImageIcon("img/cat.gif");
   JButton buttonImg = new JButton(imageIcon1);
   
   
   JPanel panelLL = new JPanel();
   JPanel panelLLI = new JPanel();
   JPanel panelLLL = new JPanel();
   JPanel panelLU = new JPanel();
   JPanel panelLD = new JPanel();
   JPanel panelLC = new JPanel();
   JPanel panel1 = new JPanel(); 
   JPanel panel2 = new JPanel(); 
   JPanel panel3 = new JPanel(); 
   JPanel panel4 = new JPanel(); 

		   
   
   String[]week= {"요일을 선택","월,수,금","화,목,토"};
   JComboBox<String>comboBox = new JComboBox<String>(week);   //요일
      
   String[]pname= {"프로그램 선택","스피닝","요가"};
   JComboBox<String>comboBox1 = new JComboBox<String>(pname);
   
   
   JButton button1 = new JButton("등록");                  //등록
   JButton button2 = new JButton("수정");                  //수정
   JButton button3 = new JButton("삭제");                  //삭제
   JButton button4 = new JButton("초기화");              //초기화
   
   JTextField testFieldProgram = new JTextField(4);            //최대인원수
   JTextField textFieldMax = new JTextField(5);            //최대인원수
   
   JTextField textFieldSerch = new JTextField(6);         //검색 필드
//   JTextField textFieldMax2 = new JTextField(3);
   
   JTextArea textArea = new JTextArea();
   JScrollPane scrollPane = new JScrollPane(textArea);
   
// 달력
   private JDatePickerImpl datePicker1;
   private JDatePickerImpl datePicker2;
   JLabel labelcal1 = new JLabel("시작일");            //달력
   JLabel labelcal2 = new JLabel("종료일");            //달력
   
//   HealthDAO dao = new HealthDAO();
   
   public ProgramFrame() {
      setTitle("헬스장 회원 등록관리");
      setSize(800, 600);
      setLocation(300, 300);
      init();
      start();
      setVisible(true);
     
     /* 
     button1.setBounds(20,5,70,30);
     button2.setBounds(20,5,70,30);
     button3.setBounds(20,5,70,30);
     button4.setBounds(20,5,70,30);
     add(button1);
     add(button2);
     add(button3);
     add(button4);
     */

   }
   public static void main(String[] args) {
         SwingUtilities.invokeLater(new Runnable() {          
            @Override
            public void run() {
               new ProgramFrame().setVisible(true);
            }
         });
      }
      
   private void init() {
      
         // 달력 //add(labelcal1);
         // 시작일
         UtilDateModel model = new UtilDateModel();
         model.setDate(2021,1,3);
         model.setSelected(true);
         
         JDatePanelImpl datePanel = new JDatePanelImpl(model);
         
         datePicker1 = new JDatePickerImpl(datePanel, new DateLabelFormatter());
         
//         JButton buttonOK = new JButton("OK");
//         buttonOK.addActionListener(this);
//         add(buttonOK);
         // 종료일
         
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setLocationRelativeTo(null);

         //add(labelcal2);
         UtilDateModel model1 = new UtilDateModel();
         model.setDate(2021, 1, 3);
         model.setSelected(true);
      
         JDatePanelImpl datePanel1 = new JDatePanelImpl(model1);
         
         datePicker2 = new JDatePickerImpl(datePanel1, new DateLabelFormatter());
         
//         JButton buttonOK = new JButton("OK");
//         buttonOK.addActionListener(this);
         
//         add(buttonOK);
         
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setLocationRelativeTo(null);
         
      
      //frame 구성
      container.setLayout(new BorderLayout());
      container.add("Center", panelR);   //중앙
      container.add("West", panelL);    //왼쪽
      
      panelL.setBorder(new TitledBorder(new BevelBorder(BevelBorder.RAISED),"프로그램 정보 입력"));
      panelL.setLayout(new BorderLayout());
      panelL.add("North",panelLL);  //왼쪽위
      panelL.add("South",panelLD);   //왼쪽아래
      panelL.add("Center",panelLC);  //왼쪽중앙
      
      panelLC.setLayout(new FlowLayout());
      panelLC.add(buttonImg);
      
//      panelLL.setLayout(new GridLayout(5,4));
//      //panelLL.setLayout(new FlowLayout());
//      panelLL.add(labelPname);                  //프로그램명 라벨
//      panelLL.add(comboBox1);                  //프로그램 선택
//      panelLL.add(labelPweek);                  //요일 라벨
//      panelLL.add(comboBox);                  //요일 선택
//      panelLL.add(labelPstart);                  //시작일 라벨
//      panelLL.add(datePicker1);                  //시작일 달력
//      panelLL.add(labelPsend);                  //종료일 라벨
//      panelLL.add(datePicker2);                  //종료일 달력   
//      panelLL.add(labelPsmax);                  //최대인원 라벨
//      panelLL.add(textFieldMax);               //최대인원 필드
      
      panelLL.setLayout(new GridLayout(4, 1, 5, 5));
      panelLL.add(panel1);
      panelLL.add(panel2);
      panelLL.add(panel3);
      panelLL.add(panel4);
      
      panel1.setLayout(new FlowLayout(FlowLayout.LEFT));
      panel1.add(labelPname);                  //프로그램명 라벨
      panel1.add(testFieldProgram);                  //프로그램 선택
      panel1.add(labelPweek);                  //요일 라벨
      panel1.add(comboBox);                  //요일 선택
         
      
      panel2.setLayout(new FlowLayout(FlowLayout.LEFT));
      panel2.add(labelPstart);                  //시작일 라벨
      panel2.add(datePicker1);                  //시작일 달력
      panel2.add(labelPsend);                  //종료일 라벨
      panel2.add(datePicker2);                  //종료일 달력  

      panel3.setLayout(new FlowLayout(FlowLayout.LEFT));
      panel3.add(labelPsend);                  //종료일 라벨
      panel3.add(datePicker2);                  //종료일 달력 
      
      panel4.setLayout(new FlowLayout(FlowLayout.LEFT));
      panel4.add(labelPsmax);                  //최대인원 라벨
      panel4.add(textFieldMax);               //최대인원 필드
      
//      panelLL.setLayout(new BorderLayout());
//      panelLL.add("West",panelLLI);
//      panelLL.add("Center",panelLLL);
//      
//      panelLL.setLayout(new GridLayout(5,1,3,3));
//      panelLLI.add(labelPname);
//      panelLLI.add(labelPweek);
//      panelLLI.add(labelPstart);
//      panelLLI.add(labelPsend);
//      panelLLI.add(labelPsmax);
//      
//      
//      panelLL.setLayout(new GridLayout(5,1,3,3));
//      panelLLL.add(comboBox1);
//      panelLLL.add(comboBox);
//      panelLLL.add(datePicker1);
//      panelLLL.add(datePicker2);
//      panelLLL.add(textFieldMax);
//      
//      comboBox1.setLayout(new FlowLayout(FlowLayout.LEFT));
//      comboBox1.add(labelPname);
      
      panelLD.setLayout(new FlowLayout());
      panelLD.add(button1);               //등록
      panelLD.add(button2);               //수정
      panelLD.add(button3);               //삭제
      panelLD.add(button4);               //초기화
      
      panelR.setBorder(new TitledBorder(new BevelBorder(BevelBorder.RAISED),"프로그램 리스트"));
            
      panelR.setLayout(new BorderLayout());
      panelR.add("North",panelRR);
      panelR.add("Center",scrollPane);
      
      panelRR.setLayout(new FlowLayout(FlowLayout.LEFT));
      panelRR.add(labelPname1);            //프로그램명 라벨
      panelRR.add(textFieldSerch);         //프로그램 텍스트 필드
      panelRR.add(button6);               //오른쪽 검색
      panelRR.add(button7);               //오른쪽 전체검색
    
 
//      panelR.add("North",panelRR);
//      panelRR.add("Center",panelRU);
//            
//       
//      panelRU.setLayout(new FlowLayout());
//      panelRU.add(button6);
//      panelRU.add(button7);
//      
//      panelRR.setLayout(new FlowLayout());
//      panelRR.add(labelPname1);
//      panelRR.add(textFieldSerch);
//           
      
   }
   private void start() {
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      
      button1.addActionListener(this);   //등록
      button2.addActionListener(this);   //수정
      button3.addActionListener(this);   //삭제
      button4.addActionListener(this);   //초기화
      button6.addActionListener(this);   //검색
      button7.addActionListener(this);   //전체
//      textFieldSerch.addActionListener(this);      
   }
	@Override
	public void actionPerformed(ActionEvent e) {
//	   Date selectedDate = (Date) datePicker1.getModel().getValue();
//	   Date selectedDate1 = (Date) datePicker2.getModel().getValue();   
	    
//	    if(e.getSource() == textFieldSerch) { // 프로그램 검사로 해놓음
//	       textFieldSerch.setText("");
//	      String p_program = pte.getText();
//	      if(p_program.equals("")) {
//	         textAreapro.setText("이름을 입력하세요");
//	         return;
//	    }
	   ProgramDTO dto = new ProgramDTO();
	   ProgramDAO dao = new ProgramDAO();
	   
	   // Left 하단 버튼 클릭 이벤트 작동 처리
	   if(e.getSource() == button1) {

//		   dto.setP_number();  -> 입력칸 X 출력 때 1씩 증가 생성?
		   dto.setP_program(testFieldProgram.getText());
		   dto.setP_week((String) comboBox.getSelectedItem());
		   dto.setP_start(datePicker1.getJFormattedTextField().getText());
		   dto.setP_end(datePicker2.getJFormattedTextField().getText());
		   dto.setP_max(textFieldMax.getText());
		   
			int result = dao.insertArticle(dto);
			if(result > 0) {
				JOptionPane.showMessageDialog(null, "등록 완료");
			}
	   } else if(e.getSource() == button2) {
		   
	   } else if(e.getSource() == button3) {
		   
	   } else if(e.getSource() == button4) {
		   
	   }
	   
	   // Right 상단 버튼 클릭 이벤트 작동 처리
	   if(e.getSource() == button6) {
		   
	   } else if(e.getSource() == button7) {
		   
		   textArea.setText("");
	         
	       List<ProgramDTO> list = dao.selectList();
	       for(int i=0; i<list.size(); i++) {
	          dto = list.get(i);
	          output(dto);
	         }
	   }	   	   
	}
	   private void output(ProgramDTO dto) {
//		   String str = "번호 : " + dto.getP_number() + "\n"
//		            + "프로그램명 : " + dto.getP_program() + "\n"
//		            + "요일 : " + dto.getP_week() + "\n"
//		            +"시작일 : " + dto.getP_start() +"\n"
//		            +"종료일 : " + dto.getP_end() + "\n"
//		            +"최대인원 : " + dto.getP_max() + "\n";
		   String str = "번호 : " + dto.getP_number() + " "
		            + "프로그램명 : " + dto.getP_program() + " "
		            + "요일 : " + dto.getP_week() + " "
		            +"시작일 : " + dto.getP_start() +" "
		            +"종료일 : " + dto.getP_end() + " "
		            +"최대인원 : " + dto.getP_max() + " \n";
		      
		      textArea.append(str);
	   }
}

