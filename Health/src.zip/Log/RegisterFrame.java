package Log;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

public class RegisterFrame extends JFrame implements ActionListener {
	
	LogDAO dao = new LogDAO();
	/** 1. 회원가입창  **/	
	
	Container container = getContentPane();
	
	// 메인 상단 컴포넌트
	JPanel RpanelMain = new JPanel();									// 상단 라벨
	JPanel RpanelTop = new JPanel();
	JLabel RlabelMain = new JLabel("관리자등록", JLabel.CENTER);			// 상단 - label	
		
	/** 1-1. 메인 중단 구성 **/
	
	// 메인 중단 컴포넌트
	JPanel RpanelCenter = new JPanel();									// 가운데 - label, textfield
	JPanel RpanelTel = new JPanel();
	JPanel RpanelGender = new JPanel();
	JPanel RpanelEast = new JPanel(); 									// 여백 설정 패널
	
	JLabel RlabelId = new JLabel("아이디 : ", JLabel.CENTER);
	JLabel RlabelPw = new JLabel("비밀번호 : ", JLabel.CENTER);
	JLabel RlabelName = new JLabel("이름 : ", JLabel.CENTER);
	JLabel RlabelGender = new JLabel("성별 : ", JLabel.CENTER);
	JLabel RlabelTel = new JLabel("전화번호 : ", JLabel.CENTER);
	JLabel RlabelAddress = new JLabel("주소 : ", JLabel.CENTER);
	
	JTextField RtextFieldId = new JTextField(15);
	JPasswordField RtextFieldPw = new JPasswordField(15);
	JTextField RtextFieldName = new JTextField(15);	
	JTextField RtextFieldTel2 = new JTextField(6);
	JTextField RtextFieldTel3 = new JTextField(6);	
	JTextField RtextFieldTel1 = null;
	JTextField RtextFieldAddress = new JTextField(15);
		
	// 성별 
	JRadioButton RradioButton1 = new JRadioButton("남자", true); 
	JRadioButton RradioButton2 = new JRadioButton("여자"); 
	ButtonGroup RbuttonGroup = new ButtonGroup();
		
	// 핸드폰번호 
	//String tel = dto.getTel();
	//String[] tels = tel.split("-");
	String[] phonenum = { "010", "011", "017"};
	JComboBox<String> comboBox = new JComboBox<String>(phonenum);

	/** 1-1. 메인 중단 컴포넌트 구성 완료 **/
	
	// 메인 하단 컴포넌트
	JPanel RpanelBot = new JPanel();									// 하단 - button
	JButton RbuttonJoin = new JButton("가입");
	JButton RbuttonCancel = new JButton("취소");
	
	public RegisterFrame() {
		setTitle("관리자등록");
		setSize(500, 650);
		setLocationRelativeTo(null);									// 로그인창 가운데 배치
		setResizable(false);											// 창 크기 조절 불가
		
		init();															// 화면 구성
		start();														// 동작 
		
		setVisible(true);
	}
	private void init() {
		
		/** 1. 회원가입창  **/	
		
		// 전체 frame 구성
		container.setLayout(new BorderLayout());
		container.add("East", RpanelEast);
		container.add("North", RpanelTop);								
		container.add("Center", RpanelCenter);
		container.add("South", RpanelBot);
		
		// 상단 라벨 위치
		RpanelTop.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 40));
		RpanelTop.add(RlabelMain);
		
		// 중단 라벨, 텍스트 위치		
		// 왼쪽, 오른쪽 여백 조정(줄맞춤)
		RpanelEast.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 20));
		
		// 아이디
		RpanelCenter.setLayout(new GridLayout(7, 2, 25, 25));
		RpanelCenter.add(RlabelId);
		RpanelCenter.add(RtextFieldId);
		
		// 패스워드
		RpanelCenter.add(RlabelPw);
		RpanelCenter.add(RtextFieldPw);
		
		// 이름
		RpanelCenter.add(RlabelName);
		RpanelCenter.add(RtextFieldName);
				
		// 성별 
		RpanelCenter.add(RlabelGender);		
		RpanelCenter.add(RpanelGender);
		RpanelGender.add(RradioButton1);
		RpanelGender.add(RradioButton2);
		RbuttonGroup.add(RradioButton1);
		RbuttonGroup.add(RradioButton2);
		
		// 전화번호 
		RpanelCenter.add(RlabelTel);
		RpanelCenter.add(RpanelTel);		
		RpanelTel.setLayout(new GridLayout(1, 3, 10, 10));
		RpanelTel.add(comboBox);
		RpanelTel.add(RtextFieldTel2);
		RpanelTel.add(RtextFieldTel3);	
		
		// 주소
		RpanelCenter.add(RlabelAddress);
		RpanelCenter.add(RtextFieldAddress);		
		
		// 하단 버튼 위치	
		RpanelBot.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 40));	// 버튼 위치 조정
		RpanelBot.add(RbuttonJoin);
		RbuttonJoin.setPreferredSize(new Dimension(80, 40));			// 버튼 크기 조절
		RpanelBot.add(RbuttonCancel);
		RbuttonCancel.setPreferredSize(new Dimension(80, 40));			// 버튼 크기 조절

		// 회원가입창 디자인 구성 
		RlabelMain.setFont(new Font("배달의민족 주아체", Font.BOLD, 40));
		
		RlabelId.setFont(new Font("배달의민족 주아체", Font.BOLD, 17));
		RlabelPw.setFont(new Font("배달의민족 주아체", Font.BOLD, 17));		
		RlabelName.setFont(new Font("배달의민족 주아체", Font.BOLD, 17));		
		RlabelGender.setFont(new Font("배달의민족 주아체", Font.BOLD, 17));		
		RlabelTel.setFont(new Font("배달의민족 주아체", Font.BOLD, 17));		
		RlabelAddress.setFont(new Font("배달의민족 주아체", Font.BOLD, 17));		
		
		RbuttonJoin.setBorder(new BevelBorder(BevelBorder.RAISED));
		RbuttonJoin.setFont(new Font("배달의민족 주아체", Font.BOLD, 16));
		RbuttonCancel.setBorder(new BevelBorder(BevelBorder.RAISED));
		RbuttonCancel.setFont(new Font("배달의민족 주아체", Font.BOLD, 16));
		
		RradioButton1.setFont(new Font("배달의민족 주아체", Font.BOLD, 14));
		RradioButton2.setFont(new Font("배달의민족 주아체", Font.BOLD, 14));		
	}

	private void start() {
		dispose();														// 해당 프레임 종료	
		RbuttonJoin.addActionListener(this);
		//RbuttonJoin
		
		RbuttonCancel.addActionListener(this);		
	}
	@Override
	public void actionPerformed(ActionEvent e) {		

		LogDTO dto = new LogDTO();
		// 가입 버튼 설정
		if(e.getSource() == RbuttonJoin) {
			dto.setId(RtextFieldId.getText());
			dto.setPw(RtextFieldPw.getText());
			dto.setName(RtextFieldName.getText());
			if(RradioButton1.isSelected()) {
				dto.setGender(RradioButton1.getText());
			} else {
				dto.setGender(RradioButton2.getText());
			}
			dto.setTel((String) comboBox.getSelectedItem() + RtextFieldTel2.getText() + RtextFieldTel3.getText());
			dto.setAddress(RtextFieldAddress.getText());
			
			int result = dao.insertMember(dto);
			
			if(result > 0) {
				JOptionPane.showMessageDialog(null, "가입 완료");
				dispose();
			} else {		
				if(RtextFieldId.getText().trim().length()==0 || RtextFieldId.getText().trim().equals("아이디")) {
					JOptionPane.showMessageDialog(null, "아이디를 입력해 주세요.", "아이디 입력", JOptionPane.WARNING_MESSAGE);
					RtextFieldId.grabFocus();
					return;
				}
				if(RtextFieldPw.getText().trim().length()==0) {
					JOptionPane.showMessageDialog(null, "비밀번호를 입력해 주세요.", "비밀번호 입력", JOptionPane.WARNING_MESSAGE);
					RtextFieldPw.grabFocus();
					return;
				}
				if(RtextFieldTel2.getText().trim().length()==0) {
					JOptionPane.showMessageDialog(null, "전화번호를 입력해 주세요.", "전화번호 입력", JOptionPane.WARNING_MESSAGE);
					RtextFieldTel2.grabFocus();
					return;
				}
				if(RtextFieldName.getText().trim().length()==0 || RtextFieldName.getText().trim().equals("이름")) {
					JOptionPane.showMessageDialog(null, "이름을 입력해 주세요.", "이름 입력", JOptionPane.WARNING_MESSAGE);
					RtextFieldName.grabFocus();
					return;
				}
				if(RtextFieldAddress.getText().trim().length()==0 || RtextFieldAddress.getText().trim().equals("주소")) {
					JOptionPane.showMessageDialog(null, "주소를 입력해 주세요.", "주소 입력", JOptionPane.WARNING_MESSAGE);
					RtextFieldAddress.grabFocus();
					return;
				}
				//JOptionPane.showMessageDialog(null, "가입 실패");
			}		
		}		
		else if(e.getSource() == RbuttonCancel) {
			dispose();
		}
	}
}