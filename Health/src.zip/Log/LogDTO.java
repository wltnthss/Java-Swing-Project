package Log;

public class LogDTO {
	private String id;		// 아이디 
	private String pw;		// 패스워드 
	private String name;	// 이름
	private String gender;	// 성별
	private String address;	// 주소
	private String tel;		// 전화번호
		
	public LogDTO() {
		super();
	}	
	public String getId() {
		return id;
	}
	public LogDTO(String id, String pw, String name, String gender, String address, String tel) {
		super();
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.gender = gender;
		this.address = address;
		this.tel = tel;
	}	
	
	// DTO 객체 확인용 toString() 함수
	@Override
	public String toString() {
		return "LogDTO [id=" + id + ", pw=" + pw + ", name=" + name + ", gender=" + gender + ", address=" + address
				+ ", tel=" + tel + "]";
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
}
