package Log;

public class ProgramDTO {
   private int p_number; 
    private String p_program; 
    private String p_week;
    private String p_start;
    private String p_end;
    private String p_max;
    
   public ProgramDTO() {
      super();
   }

   public ProgramDTO(int p_number, String p_program, String p_week, String p_start, String p_end, String p_max) {
      super();
      this.p_number = p_number;
      this.p_program = p_program;
      this.p_week = p_week;
      this.p_start = p_start;
      this.p_end = p_end;
      this.p_max = p_max;
   }
   
   @Override
   public String toString() {
      return "ProgramDTO [p_number=" + p_number + ", p_program=" + p_program + ", p_week=" + p_week + ", p_start="
            + p_start + ", p_end=" + p_end + ", p_max=" + p_max + "]";
   }
   public int getP_number() {
	   int p_number = 0;
	   p_number += 1;
      return p_number;
   }
   public void setP_number(int p_number) {
      this.p_number = p_number;
   }
   public String getP_program() {
      return p_program;
   }
   public void setP_program(String p_program) {
      this.p_program = p_program;
   }
   public String getP_week() {
      return p_week;
   }
   public void setP_week(String p_week) {
      this.p_week = p_week;
   }
   public String getP_start() {
      return p_start;
   }
   public void setP_start(String p_start) {
      this.p_start = p_start;
   }
   public String getP_end() {
      return p_end;
   }
   public void setP_end(String p_end) {
      this.p_end = p_end;
   }
   public String getP_max() {
      return p_max;
   }

   public void setP_max(String p_max) {
      this.p_max = p_max;
   }
    
   
    
}