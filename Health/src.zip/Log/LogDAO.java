package Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LogDAO {
	
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String user = "C##health";
	String pass = "m1234";
	
	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	LogDTO dto = new LogDTO();
	
	// 1. 드라이버 연결
	public LogDAO() {
		try {
			Class.forName(driver);
			//System.out.println("드라이버 등록 성공");
		} catch (ClassNotFoundException e) {
			System.out.println("접속 실패입니다. 드라이버 연결을 확인하세요.");
			e.printStackTrace();
		}
	}
	
	// 2. DB 서버 접속
	public Connection getConnection() {
		try {
			connection = DriverManager.getConnection(url, user, pass);
			//System.out.println("서버 연결 성공");
		} catch (SQLException e) {
			System.out.println("접속 실패입니다. Oracle 연결을 확인하세요.");
			e.printStackTrace();
		}
		return connection;
	}
	
	// 3. DB 접속 종료 함수
	public void close() {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(connection != null) connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// 4. id, pw 입력
	public int idpw(String id, String pw) {
		connection = getConnection();
		pstmt = null;		
		int result = 0;
		String LOGIN = "select * from Login where id = ? and pw = ?";
		
		try {
			pstmt = connection.prepareStatement(LOGIN);
			
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				// 리턴값 설정 필요
				//System.out.println("아이디와 패스워드 생성완료");
				return 1; 
			} else {
				//System.out.println("아이디와 패스워드 확인필요");
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		// 리턴값 설정 필요
		return -1;	
	}	

	// 가입 데이터 입력 
	public int insertMember(LogDTO dto) {
		connection = getConnection();
		pstmt = null;
		int result = 0;
		String INSERT = "insert into Login values (?, ?, ?, ?, ?, ?)";
		
		try {
			pstmt = connection.prepareStatement(INSERT);
			
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getGender());
			pstmt.setString(5, dto.getAddress());
			pstmt.setString(6, dto.getTel());
	
			result = pstmt.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}						
		return result;		
	}
}
