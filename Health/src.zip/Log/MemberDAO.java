package Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MemberDAO {

    String driver = "oracle.jdbc.driver.OracleDriver";
    String url = "jdbc:oracle:thin:@localhost:1521:xe";
    String user= "C##health";
    String password = "m1234";
    // 클래스 선언
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
	
   public MemberDAO() {
      try {
         Class.forName(driver);
         //System.out.println("드라이버 등록 완료");
      } catch (ClassNotFoundException e) {
    	  System.out.println("드라이버 등록 실패");
         e.printStackTrace();
      }
   }

   // 2. db 서버에 접속
   public Connection getConnection() {
      Connection conn = null;

      // DriverManaget.getConnection("URL 주소");
      try {
         conn = DriverManager.getConnection(url, user, password);
         //System.out.println("서버 접속 완료");
      } catch (SQLException e) {
          System.out.println("서버 접속 실패");
         e.printStackTrace();
      }
      return conn;
   }
   // 3. DB 접속 종료
   public void close() {
       try {
          if(rs != null) rs.close();
          if(pstmt != null) pstmt.close();
          if(conn != null) conn.close();
       } catch (SQLException e) {
          e.printStackTrace();
       }
    }
   
   // insert
   public int insertArticle(MemberDTO dto) {
      int result = 0;
      // insert into Member values ('홍길동', '202101, 1');
      String sql = "insert into member values(seq_number.nextval, ?, ?, ?, ?, ?, ?)";

      conn = getConnection();
 
      try {
         pstmt = conn.prepareStatement(sql);
//         pstmt.setInt(1, dto.getm_number());
//         pstmt.setString(2, dto.getm_name());
//         pstmt.setInt(3, dto.getm_age());
//         pstmt.setString(4, dto.getm_gender());
//         pstmt.setInt(5, dto.getm_tel());
//         pstmt.setString(6, dto.getm_Email());
//         pstmt.setString(7, dto.getm_address());
         
       pstmt.setString(1, dto.getm_name());
       pstmt.setInt(2, dto.getm_age());
       pstmt.setString(3, dto.getm_gender());
       pstmt.setInt(4, dto.getm_tel());
       pstmt.setString(5, dto.getm_Email());
       pstmt.setString(6, dto.getm_address());
         
         result = pstmt.executeUpdate();
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
    	  close();
      }
      // 결과 리턴
      return result;
   }
   // delete
   public int deleteArticle(String m_name) {
      int result = 0;
      String sql = "delete member where m_name=?";

      conn = getConnection();
      try {
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, m_name);
         result = pstmt.executeUpdate();
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
    	  close();
      }
      return result;
   }

   // 전체 검색
   public List<MemberDTO> selectList() {
      List<MemberDTO> list = new ArrayList<MemberDTO>();
      String sql = "select * from Member";

      Connection conn = getConnection();
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      try {
         pstmt = conn.prepareStatement(sql);
         rs = pstmt.executeQuery();
         while (rs.next()) {
        	int m_number = rs.getInt("m_number");
            String m_name = rs.getString("m_name");
            int m_age = rs.getInt("m_age");
            String m_gender = rs.getString("m_gender");
            int m_tel = rs.getInt("m_tel");
            String m_Email = rs.getString("m_Email");
            String m_address = rs.getString("m_address");
            MemberDTO dto = new MemberDTO(m_number, m_name, m_age, m_gender, m_tel, m_Email, m_address);

            list.add(dto);
         }
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
    	  close();
      }
      return list;
   }

   // 부분 검색
   public List<MemberDTO> selectPart(String m_name) {
      List<MemberDTO> list = new ArrayList<MemberDTO>();
      String sql = "select * from member where m_name like?";

      conn = getConnection();

      try {
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, "%" + m_name + "%");
         rs = pstmt.executeQuery();
         while (rs.next()) {
        	int m_number = rs.getInt("m_number");
            String m_name1 = rs.getString("m_name");
            int m_age = rs.getInt("m_age");
            String m_gender = rs.getString("m_gender");
            int m_tel = rs.getInt("m_tel");
            String m_email = rs.getString("m_email");
            String m_address = rs.getString("m_address");
            MemberDTO dto = new MemberDTO(m_number, m_name1, m_age, m_gender, m_tel, m_email, m_address);
            // 리스트에 저장
            list.add(dto);
         }
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
    	  close();
      }
      return list;
   }

   // 1개 검색
   public MemberDTO selectOne(String m_name) {
      // 디버깅용
      // => 함수(블록) 진입 확인
      //System.out.println("test1");
      
	   MemberDTO dto = null;
      String sql = "select*from member where m_name=?";

      Connection conn = getConnection();

      try {
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, m_name);
         rs = pstmt.executeQuery();

         if (rs.next()) {   //   1개 행 읽어오기
            // 디버깅용
            // => 제어문(블록) 진입 확인
            //System.out.println("test3");
            
            dto = new MemberDTO();
            dto.setm_name(rs.getString("name"));
            dto.setm_age(rs.getInt("age"));
            dto.setm_gender(rs.getString("gender"));
            dto.setm_tel(rs.getInt("tel"));
            dto.setm_Email(rs.getString("Email"));
            dto.setm_address(rs.getString("address"));
         }
         // 디버깅용 :
         // 1. 이 함수에 진입을 했는지 확인
         // 2. 여기까지 명령어가 진행되었는지 확인
         // 3. 내가 원하는 값이 제대로 저장되었는지 확인
         //System.out.println("dto : " + dto.toString());
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
    	  close();
      }
      return dto;
   }

   public int updateArticle(MemberDTO dto) {
	   conn = getConnection();
	   int result = 0;
	   String sql = "update member set m_age = ?, m_gender = ?, m_tel = ?, m_email = ?, m_address = ? where m_name = ?";
	   
	   try {
		pstmt = conn.prepareStatement(sql);

		pstmt.setInt(1, dto.getm_age());
		pstmt.setString(2, dto.getm_gender());
		pstmt.setInt(3, dto.getm_tel());
		pstmt.setString(4, dto.getm_Email());
		pstmt.setString(5, dto.getm_address());
		pstmt.setString(6, dto.getm_name());
		result = pstmt.executeUpdate();
		
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		close();
	}
	return result;	   
   }
}
