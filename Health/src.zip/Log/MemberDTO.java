package Log;

public class MemberDTO {
   private int m_number;
   private String m_name;
   private int m_age;
   private String m_gender;
   private int m_tel;
   private String m_Email;
   private String m_address;
   
   public MemberDTO() {
      super();
      
   }
   public MemberDTO(int m_number, String m_name, int m_age, String m_gender, int m_tel, String m_Email, String m_address) {
      super();
      this.m_number = m_number;
      this.m_name = m_name;
      this.m_age = m_age;
      this.m_gender = m_gender;
      this.m_tel = m_tel;
      this.m_Email = m_Email;
      this.m_address = m_address;
   }
   public int getm_number() {
      return m_number;
   }
   public void setm_number(int m_number) {
      this.m_number = m_number;
   }
   public String getm_name() {
      return m_name;
   }
   public void setm_name(String m_name) {
      this.m_name = m_name;
   }
   public int getm_age() {
      return m_age;
   }
   public void setm_age(int m_age) {
      this.m_age = m_age;
   }
   public String getm_gender() {
      return m_gender;
   }
   public void setm_gender(String m_gender) {
      this.m_gender = m_gender;
   }
   public int getm_tel() {
      return m_tel;
   }
   public void setm_tel(int m_tel) {
      this.m_tel = m_tel;
   }
   public String getm_Email() {
      return m_Email;
   }
   public void setm_Email(String m_Email) {
      this.m_Email = m_Email;
   }
   public String getm_address() {
      return m_address;
   }
   public void setm_address(String m_address) {
      this.m_address = m_address;
   }        
}