package Log;

public class LogMain {
	public static void main(String[] args) {
				
		//test 
//		LogDAO dao = new LogDAO();
				
		new LogFrame();
	}
}
