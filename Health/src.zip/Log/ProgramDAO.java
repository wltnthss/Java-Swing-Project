package Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ProgramDAO {
   // 커넥션 설정
      String driver = "oracle.jdbc.driver.OracleDriver";
      String url = "jdbc:oracle:thin:@localhost:1521:xe";
      String user= "C##health";
      String password = "m1234";
      // 클래스 선언
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      
      // 1) OracleDriver 클래스 등록 확인
      public ProgramDAO() {
         try {
            Class.forName(driver);
            //System.out.println("등록 성공");
         } catch (ClassNotFoundException e) {
            System.out.println("등록 실패");
            e.printStackTrace();
         }
      }
      // 2) DB 접속 함수
      public Connection getConnection() {
         try {
            conn = DriverManager.getConnection(url, user, password);
            //System.out.println("접속 성공");
         } catch (SQLException e) {
            System.out.println("접속 실패");
            e.printStackTrace();
         }
         return conn;
      }
      // 3) DB 접속 종료 함수 - 중복해서 쓰는 함수여서 함수로 만듦
      public void close() {
         try {
            if(rs != null) rs.close();
            if(pstmt != null) pstmt.close();
            if(conn != null) conn.close();
         } catch (SQLException e) {
            e.printStackTrace();
         }
      }
      // 4) insert 기능 함수
      public int insertArticle(ProgramDTO dto) {
         // 함수에 진입했는지 test
         System.out.println("test");
         int result = 0;
         String sql = " insert into program values(?, ?, ?, ?, ?, ?)";
         
         conn = getConnection();
         try {
            pstmt = conn.prepareStatement(sql);
//            pstmt.setString(1, dto.getP_number());
            pstmt.setInt(1, dto.getP_number());
            pstmt.setString(2, dto.getP_program());
            pstmt.setString(3, dto.getP_week());
            pstmt.setString(4, dto.getP_start());
            pstmt.setString(5, dto.getP_end());
            pstmt.setString(6, dto.getP_max());            
            
//            pstmt.setString(1, dto.getP_program());
//            pstmt.setString(2, dto.getP_week());
//            pstmt.setString(3, dto.getP_start());
//            pstmt.setString(4, dto.getP_end());
//            pstmt.setString(5, dto.getP_max());
            result = pstmt.executeUpdate();
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         // result 값 확인해보기 - 오류 확인(블럭에 진입했는지 확인)
         //System.out.println("result = " + result);
         return result;
      }
      // 5) delete 기능 함수
      public int deleteArticle(String name) {
         // 함수에 진입했는지 test
         System.out.println("test");
         int result = 0;
         String sql = " delete school where p_program =?";
         
         conn = getConnection();
         try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            result = pstmt.executeUpdate();
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         // result 값 확인해보기 - 오류 확인(블럭에 진입했는지 확인)
         //System.out.println("result = " + result);
         return result;
      }
      // 6) select : 전체 검색
      public List<ProgramDTO> selectList() {
         List<ProgramDTO> list = new ArrayList<ProgramDTO>();
         String sql = "select * from program";
         
         conn = getConnection();
         try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while(rs.next()) {   // 1개행 읽어오기
               int p_number = rs.getInt("p_number");
               String p_program = rs.getString("p_program");
               String p_week = rs.getString("p_week");
               String p_start = rs.getString("p_start");
               String p_end = rs.getString("p_end");
               String p_max = rs.getString("p_max");
               ProgramDTO dto = new ProgramDTO(p_number,p_program, p_week,p_start, p_end, p_max);
               // 리스트에 저장
               list.add(dto);
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         return list;
      }
      // 7) select : 부분 검색
      public List<ProgramDTO> selectPart(String p_program) {
         List<ProgramDTO> list = new ArrayList<ProgramDTO>();
         String sql = "select * from program where p_program like ?";
         
         conn = getConnection();
         try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + p_program + "%");
            rs = pstmt.executeQuery();
            while(rs.next()) {   // 1개행 읽어오기
               int p_number = rs.getInt("p_number");
               String p_program1 = rs.getString("p_program");
               String p_week = rs.getString("p_week");
               String p_start = rs.getString("p_start");
               String p_end = rs.getString("p_end");
               String p_max = rs.getString("p_max");
               ProgramDTO dto = new ProgramDTO(p_number,p_program, p_week,p_start, p_end, p_max);
               // 리스트에 저장
               list.add(dto);
               
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         return list;
      }
      // 8) select : 1명 검색
      public ProgramDTO selectOne(String name) {
         ProgramDTO dto = new ProgramDTO();
         String sql = "select * from program where p_program =?";
         
         conn = getConnection();
         try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            if(rs.next()) {   // 1개행 읽어오기
               int p_number = rs.getInt("number");
               String p_program = rs.getString("program");
               String p_week = rs.getString("week");
               String p_start = rs.getString("start");
               String p_end = rs.getString("end");
               String p_max = rs.getString("max");
               dto = new ProgramDTO(p_number,p_program, p_week,p_start, p_end, p_max);
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }finally {
            close();
         }
         return dto;
      }
}