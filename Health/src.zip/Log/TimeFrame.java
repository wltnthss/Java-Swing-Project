package Log;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Date;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.UtilDateModel;







public class TimeFrame extends JFrame implements ActionListener{
   Container container = getContentPane();
   
   Connection conn;
   Statement stmt;
   ResultSet rs;
   

   JPanel panelCenter = new JPanel();
   JPanel panelCL = new JPanel();
   JPanel panelCR = new JPanel();
   JPanel panelSouth = new JPanel(); // 시간관리
   JPanel panelTimeButton = new JPanel(); // 시간관리 1
   JPanel panelPro = new JPanel(); // 프로그램
   JPanel panelPro1 = new JPanel(); // 프로그램 첫번째줄
   JPanel panelPro2 = new JPanel(); // 프로그램 두번째줄
   JPanel panelPro3 = new JPanel(); // 프로그램 세번째줄
   JPanel panelPro4 = new JPanel(); // 시작일,종료일
   JPanel panelProC = new JPanel(); // 프로그램 센터
   JPanel panelTra = new JPanel(); // 트레이너
   JPanel panelTra1 = new JPanel(); // 트레이너 첫번째줄
   JPanel panelTra2 = new JPanel(); // 트레이너 두번째줄
   JPanel panelTra3 = new JPanel(); // 트레이너 세번째줄
   JPanel panelTraC = new JPanel(); // 트레이너 센터
   JPanel panelButton = new JPanel(); // 버튼패널
   JPanel panelProList = new JPanel(); // 프로그램리스트
   JPanel panelProL1 = new JPanel(); // 프로그램 리스트 1
   JPanel panelProL2 = new JPanel(); // 프로그램 리스트 1
   JPanel panelTraList = new JPanel(); // 트레이너리스트
   JPanel panelTraL1 = new JPanel(); // 트레이너 리스트 1
   
   
   // 프로그램 정보
   JLabel plabel1 = new JLabel("프로그램 번호 ");
   JLabel plabel2 = new JLabel("프로그램명 ");
   JLabel plabel3 = new JLabel("시작일 ");
   JLabel plabel4 = new JLabel("종료일 ");
   JLabel plabel5 = new JLabel("요일 ");
   JLabel plabel6 = new JLabel("최대인원 ");
   JTextField ptextField1 = new JTextField(3);
   JTextField ptextField2 = new JTextField(3);
   JTextField ptextField3 = new JTextField(3);
   JTextField ptextField4 = new JTextField(3);
   JTextField ptextField5 = new JTextField(3);
   JTextField ptextField6 = new JTextField(3);
   
   // 트레이너 정보
   JLabel tlabel1 = new JLabel("트레이너 이름");
   JLabel tlabel2 = new JLabel("나이");
   JLabel tlabel3 = new JLabel("전화번호");
   JLabel tlabel4 = new JLabel("성별");
   JLabel tlabel5 = new JLabel("메일");
   JLabel tlabel6 = new JLabel("주소");
   
   JTextField ttextField1 = new JTextField(3);
   JTextField ttextField2 = new JTextField(3);
   JTextField ttextField3 = new JTextField(3);
   JTextField ttextField4 = new JTextField(3);
   JTextField ttextField5 = new JTextField(3);
   JTextField ttextField6 = new JTextField(3);
   
   
   // 버튼
   JButton button1 = new JButton("등록");   
   JButton button2 = new JButton("수정");   
   JButton button3 = new JButton("삭제");   
   JButton button4 = new JButton("초기화");   
   
   
   // 프로그램 리스트
   JLabel labelpname = new JLabel("프로그램명 ");
   JTextField ptextfieldname = new JTextField(6);
   JButton search1 = new JButton("검색");
   JButton all1 = new JButton("전체");
   
   // 트레이너 리스트
   JLabel labeltname = new JLabel("이름");
   JTextField ttextFieldname = new JTextField(3);
   JButton search2 = new JButton("검색");
   JButton all2 = new JButton("전체");
   
   // 시간 리스트
   JButton buttonall = new JButton("전체");
   
   JTextArea textAreapro = new JTextArea();
   JTextArea textAreatra = new JTextArea();
   JTextArea textAreatime = new JTextArea();
   JScrollPane scrollPanepro = new JScrollPane(textAreapro);
   JScrollPane scrollPanetra = new JScrollPane(textAreatra);
   JTable tablepro = new JTable();
   JScrollPane scrollPanetime = new JScrollPane(tablepro);
   
   
         
   // 프로그램 리스트 표
   //String[] colNamespro = new String[] {"번호", "프로그램명", "요일", "시작일", "종료일","최대인원"};
   //DefaultTableModel modelpro = new DefaultTableModel(colNamespro, 4);
   ; //= new JTable(modelpro);
   //JScrollPane scrollPanepro = new JScrollPane(tablepro);
//   
//   // 트레이너 리스트 표
//   String[] colNamestra = new String[] {"이름", "성별","나이", "전화번호", "메일", "주소"};
//   DefaultTableModel modeltra = new DefaultTableModel(colNamestra, 4);
//   JTable tabletra = new JTable(modeltra);
//   JScrollPane scrollPanetra = new JScrollPane(tabletra);
//   
//
//   
//   // 시간 리스트 표
//   String[] colNamestime = new String[] {"번호", "프로그램명", "요일", "시간", "시작일", "종료일","담당 트레이너", "최대인원"};
//   DefaultTableModel modeltime = new DefaultTableModel(colNamestime, 4);
//   JTable tabletime = new JTable(modeltime);
//   JScrollPane scrollPanetime = new JScrollPane(tabletime);
   
   // 달력
   private JDatePickerImpl datePicker1;
   private JDatePickerImpl datePicker2;
   JLabel labelcal1 = new JLabel("시작일");
   JLabel labelcal2 = new JLabel("종료일");
   
   ProgramDAO dao = new ProgramDAO();
   
   JTable table = new JTable();
   
   public TimeFrame() {
      setTitle("헬스 회원 관리 프로그램");
      setSize(800, 600);
      //setLocation(200, 200);
      init();
      accDb();
      start();
      setVisible(true);
   }
   
   private void accDb() {
      try {
         Class.forName("oracle.jdbc.driver.OracleDriver");
      } catch (Exception e) {
         System.out.println("오류 : " + e);
      }      
   }

   //달력 관련 메인
   public static void main(String[] args) {
      SwingUtilities.invokeLater(new Runnable() {
         
         @Override
         public void run() {
            new TimeFrame().setVisible(true);
         }
      });
   }
   
   private void init() {
      
      // 달력 //add(labelcal1);
      // 시작일
      UtilDateModel model = new UtilDateModel();
      model.setDate(2021,1,3);
      model.setSelected(true);
      
      JDatePanelImpl datePanel = new JDatePanelImpl(model);
      
      datePicker1 = new JDatePickerImpl(datePanel, new DateLabelFormatter());
      
//      JButton buttonOK = new JButton("OK");
//      buttonOK.addActionListener(this);
//      add(buttonOK);
      // 종료일
      
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLocationRelativeTo(null);

      //add(labelcal2);
      UtilDateModel model1 = new UtilDateModel();
      model.setDate(2021, 1, 3);
      model.setSelected(true);
   
      JDatePanelImpl datePanel1 = new JDatePanelImpl(model1);
      
      datePicker2 = new JDatePickerImpl(datePanel1, new DateLabelFormatter());
      
//      JButton buttonOK = new JButton("OK");
//      buttonOK.addActionListener(this);
      
//      add(buttonOK);
      
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLocationRelativeTo(null);
      
      // frame
      container.setLayout(new BorderLayout());
      container.add("Center",panelCenter);
      container.add("South",panelSouth);
      
      panelCenter.setLayout(new BorderLayout());
      panelCenter.add("West", panelCL);
      panelCenter.add("Center", panelCR);

      
      
      
      // 왼쪽
      panelCL.setLayout(new BorderLayout());
      panelCL.setBorder(new TitledBorder("시간 정보"));
      panelCL.add("North",panelPro);
      panelCL.add("Center", panelTra);
      panelCL.add("South", panelButton);
      // 버튼
      panelButton.setLayout(new GridLayout(1, 4));
      panelButton.add(button1);
      panelButton.add(button2);
      panelButton.add(button3);
      panelButton.add(button4);
      
      // 프로그램정보
      panelPro.setLayout(new BorderLayout());
      panelPro.setBorder(new TitledBorder("프로그램 정보"));
      panelPro.add("Center", panelProC);
      
      panelProC.setLayout(new GridLayout(4,1));
      panelProC.add(panelPro1);
      panelProC.add(panelPro2);
      panelProC.add(panelPro4);
      panelProC.add(panelPro3);
      
      panelPro1.setLayout(new FlowLayout());
      panelPro1.add(plabel1);
      panelPro1.add(ptextField1);
      panelPro1.add(plabel2);
      panelPro1.add(ptextField2);
      
      
      panelPro2.setLayout(new FlowLayout());
      panelPro2.add(labelcal1);
      panelPro2.add(datePicker1);
      
      panelPro4.setLayout(new FlowLayout());
      panelPro4.add(labelcal2);
      panelPro4.add(datePicker2);
      
      panelPro3.setLayout(new FlowLayout());
      panelPro3.add(plabel5);
      panelPro3.add(ptextField5);
      panelPro3.add(plabel6);
      panelPro3.add(ptextField6);
      
      // 트레이너 정보
      panelTra.setLayout(new BorderLayout());
      panelTra.setBorder(new TitledBorder("트레이너 정보"));
      panelTra.add("Center", panelTraC);
      
      panelTraC.setLayout(new GridLayout(3,1));
      panelTraC.add(panelTra1);
      panelTraC.add(panelTra2);
      panelTraC.add(panelTra3);
      
      panelTra1.setLayout(new FlowLayout());
      panelTra1.add(tlabel1);
      panelTra1.add(ttextField1);
      panelTra1.add(tlabel2);
      panelTra1.add(ttextField2);
      
      panelTra2.setLayout(new FlowLayout());
      panelTra2.add(tlabel3);
      panelTra2.add(ttextField3);
      panelTra2.add(tlabel4);
      panelTra2.add(ttextField4);
      
      panelTra3.setLayout(new FlowLayout());
      panelTra3.add(tlabel5);
      panelTra3.add(ttextField5);
      panelTra3.add(tlabel6);
      panelTra3.add(ttextField6);

      // 오른쪽
      // 프로그램 리스트
      panelCR.setLayout(new BorderLayout());
      panelCR.add("North", panelProList);
      panelCR.add("Center", panelTraList);
      
      panelProList.setLayout(new BorderLayout());
      panelProList.setBorder(new TitledBorder("프로그램 리스트"));
      panelProList.add("North", panelProL1);
      panelProList.add("South",scrollPanepro);
      scrollPanepro.setPreferredSize(new Dimension(300,100));
      
      panelProL1.setLayout(new FlowLayout());
      panelProL1.add(labelpname);
      panelProL1.add(ptextfieldname);
      panelProL1.add(search1);
      panelProL1.add(all1);
      
      // 트레이너 리스트
      panelTraList.setLayout(new BorderLayout());
      panelTraList.setBorder(new TitledBorder("트레이너 리스트"));
      panelTraList.add("North", panelTraL1);
      panelTraList.add("Center",scrollPanetra);
      scrollPanetra.setPreferredSize(new Dimension(300,100));
      
      panelTraL1.setLayout(new FlowLayout());
      panelTraL1.add(labeltname);
      panelTraL1.add(ttextFieldname);
      panelTraL1.add(search2);
      panelTraL1.add(all2);
      
      
      // 시간 리스트
      panelSouth.setLayout(new BorderLayout());
      panelSouth.setBorder(new TitledBorder("시간 리스트"));
      panelSouth.add("North", panelTimeButton);
      panelSouth.add("South", scrollPanetime);
      scrollPanetime.setPreferredSize(new Dimension(300,100));
      panelTimeButton.setLayout(new FlowLayout());
      panelTimeButton.add(buttonall);
      panelSouth.setPreferredSize(new Dimension(700,250));
      
   
      textAreapro.setEditable(false);         // read only

      
   }

   private void start() {
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      search1.addActionListener(this);
      all1.addActionListener(this);
   }


   @Override
   public void actionPerformed(ActionEvent e) {
	   TimeDAO dao = new TimeDAO();
	   TimeDTO dto = new TimeDTO();
       if (e.getSource() == search1) {
//		   System.out.println("이름검색버튼 동작");
		   String inputName = ptextfieldname.getText();
		   if(inputName.equals("")) {
//			   textArea.setText("");
			   JOptionPane.showMessageDialog(null, "이름을 입력하세요");

		   }
//		   textArea.setText("번호      이름        성별       나이       "
//		   		+ "전화번호\t      이메일\t              주소\n");
		   String name = ptextfieldname.getText();
			List<TimeDTO> list = dao.selectPart(name);
			for(int i=0; i<list.size(); i++) {
				dto = list.get(i);
				output(dto);
			}	
      } 
//       if(e.getSource() == all1) {
//         try {
//            
//            //Driver 연결
//            conn = DriverManager.getConnection(url, user, password);
//            
//            //열기
//            stmt = conn.createStatement();
//
//               String sql = "select p_number, p_program, p_week, p_start, p_end, p_max from program";
//               rs = stmt.executeQuery(sql);
//               System.out.println("룰루");
//            textAreapro.setText("번호\t프로그램명\t요일수\t시작일\t종료일\t최대인원\n");
//            while(rs.next()) {
//               String str = rs.getString("p_number") + "\t" + rs.getString("p_program") + "\t" + rs.getString("p_week") 
//               + "\t" + rs.getString("p_start") + "\t" + rs.getString("p_end") + "\t" + rs.getString("p_max") + "\n";  
//               textAreapro.append(str);
//            }
//         } catch (Exception e2) {
////            System.out.println("actionPerformed err : " + e);
//         } finally {                  
//            // 닫기 
//            try {
//               if(rs != null) rs.close();
//               if(stmt != null) stmt.close();
//               if(conn != null) conn.close();
//            } catch (Exception e2) {
//               // TODO: handle exception
//            }
//         }
//      }
      private void output(TimeDTO dto) {
    	  TimeDTO dto = new TimeDTO();
    	  
		   String str = dto.p_number() + "         "
				   		+ dto.p_program() + "        "
				   		+ dto.p_week() + "      "
				   		+ dto.getm_age() + "     "
				   		+ dto.p_start() +"\t  "
				   		+ dto.p_end() + "\t  "
				   		+ dto.p_max() + "\n";
		   
//		   		textArea.append(str);		
	}
      
      // 달력
//            Date selectedDate = (Date) datePicker1.getModel().getValue();
//            Date selectedDate1 = (Date) datePicker1.getModel().getValue();
            // 달력 dialog
            //JOptionPane.showMessageDialog(this, "The selected date is " + selectedDate);
      
      
//      if(e.getSource() == search1) { // 프로그램 검사로 해놓음
//         textAreapro.setText("");
//         String p_program = ptextfieldname.getText();
//         if(p_program.equals("")) {
//            textAreapro.setText("이름을 입력하세요");
//            return;
//         }
//         List<ProgramDTO> list = dao.selectPart(p_program);
//         for(int i=0; i<list.size(); i++) {
//            ProgramDTO dto = list.get(i);
//            output(dto);
//         }   
//      }
//      else if(e.getSource() == all1) { // 전체검색
//         textAreapro.setText("");
//         
//         List<ProgramDTO> list = dao.selectList();
//         for(int i=0; i<list.size(); i++) {
//            ProgramDTO dto = list.get(i);
//            output(dto);
//         }
//      }

//      if(e.getSource() instanceof JButton) {
//         if(e.getSource() == search1) {
//            selectList();
//         }
//      }else if(e.getSource() == all1) {
//         selectList();
//      }else if(e.getSource() instanceof JTextField) {
//         
//      }


   private void output(ProgramDTO dto) {
      String str = "번호 : " + dto.getP_number() + "\t"
            + "프로그램명 : " + dto.getP_program() + "\t"
            + "요일 : " + dto.getP_week() + "\t"
            +"시작일 : " + dto.getP_start() +"\t"
            +"종료일 : " + dto.getP_end() + "\t"
            +"최대인원 : " + dto.getP_max() + "\t\n";
      
      
      textAreapro.append(str);
      //System.out.println();
   }

}