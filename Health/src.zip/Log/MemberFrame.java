package Log;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

// Health_Member 화면 구성
public class MemberFrame {
   public static void main(String[] args) {
	   SwingUtilities.invokeLater(new Runnable() {          
           @Override
           public void run() {
        	   new Swing_Member().setVisible(true);
           }
        });
   }
}

class Swing_Member extends JFrame implements ActionListener {
   Container container = getContentPane();
   
   // West
   JPanel panelWest = new JPanel();
   JPanel panelBtn = new JPanel();
   JButton button1 = new JButton("등록");
   JButton button2 = new JButton("수정");
   JButton button3 = new JButton("삭제");
   JButton button4 = new JButton("초기화");		   
   
   // WestTop
   JPanel panelWestTop = new JPanel();
   JPanel panelWestlabel = new JPanel();
   JPanel panelWestInfor = new JPanel();
   JPanel panel1 = new JPanel();
   JPanel panel2 = new JPanel();
   JPanel panel3 = new JPanel();
   JPanel panel4 = new JPanel();
   
   JLabel labelName = new JLabel("이름 ", JLabel.RIGHT);
   JLabel labelAge = new JLabel("나이 ", JLabel.RIGHT);
   JLabel labelTel = new JLabel("전화번호 ", JLabel.RIGHT);
   JLabel labelEmail = new JLabel("메일 ", JLabel.RIGHT);
   JLabel labelAddress = new JLabel("주소 ", JLabel.RIGHT);
   
   JTextField textFieldName = new JTextField(12);
   JTextField textFieldAge = new JTextField(3);
   JTextField textFieldTel = new JTextField(12);
   JTextField textFieldEmail = new JTextField(15);
   JTextField textFieldAddress = new JTextField(20);     
   
   JRadioButton radioButton1 = new JRadioButton("남성", true); 
   JRadioButton radioButton2 = new JRadioButton("여성");
   ButtonGroup buttonGroup = new ButtonGroup();
   
   JButton buttonSend = new JButton("전송");
   
   // WestBot
   JPanel panelWestBot = new JPanel();
   ImageIcon imageIcon1 = new ImageIcon("img/cat.gif");
   JButton buttonImg = new JButton(imageIcon1);
   
   // Center
   JPanel panelCenter = new JPanel();
   JPanel panel5 = new JPanel();
   JLabel labelMName = new JLabel("이름 ", JLabel.RIGHT);
   JTextField textFieldMName = new JTextField(12);
   JButton buttonSearchPart = new JButton("검색");
   JButton buttonSearchAll = new JButton("전체");
   
   JTextArea textArea = new JTextArea();
   JScrollPane scrollPane = new JScrollPane(textArea);
//   String[] str = {"번호", "이름", "성별", "나이", "전화번호", "이메일", "주소"};
//	
//   DefaultTableModel defaultTableModel = new DefaultTableModel(str, 5);
//   
//   JTable table = new JTable(defaultTableModel);
//   JScrollPane scrollPane = new JScrollPane(table);
   
   public Swing_Member() {
      setTitle("헬스장 회원 관리");
      setSize(800,600);
      setLocationRelativeTo(null);  
      init();
      start();
      setVisible(true);
   }

   private void init() {
	   
	   // 전체 Frame 구성
	   container.setLayout(new BorderLayout());
	   container.add("West", panelWest);
	   container.add("Center", panelCenter);
	   
	   // panelWest
	   panelWest.setBorder(new TitledBorder(new BevelBorder(BevelBorder.RAISED), "회원 정보 입력"));
	   panelWest.setLayout(new BorderLayout());
	   panelWest.add("North", panelWestTop);
	   panelWest.add("Center", panelWestBot);
	   panelWest.add("South", panelBtn);
	   
	   panelBtn.setLayout(new GridLayout(1, 4));
	   panelBtn.add(button1);
	   panelBtn.add(button2);
	   panelBtn.add(button3);
	   panelBtn.add(button4);
	   
	   // panelWestTop
	   panelWestTop.setLayout(new BorderLayout());
	   panelWestTop.add("West", panelWestlabel);
	   panelWestTop.add("Center", panelWestInfor);
	   
	   panelWestlabel.setLayout(new GridLayout(4, 1, 5, 5));
	   panelWestlabel.add(labelName);
	   panelWestlabel.add(labelAge);
	   panelWestlabel.add(labelEmail);
	   panelWestlabel.add(labelAddress);
	   
	   panelWestInfor.setLayout(new GridLayout(4, 1, 5, 5));
	   panelWestInfor.add(panel1);
	   panelWestInfor.add(panel2);
	   panelWestInfor.add(panel3);
	   panelWestInfor.add(panel4);
	   
	   panel1.setLayout(new FlowLayout(FlowLayout.LEFT));
	   panel1.add(textFieldName);
	   panel1.add(radioButton1);
	   panel1.add(radioButton2);
	   buttonGroup.add(radioButton1);
	   buttonGroup.add(radioButton2);
	   
	   panel2.setLayout(new FlowLayout(FlowLayout.LEFT));
	   panel2.add(textFieldAge);
	   panel2.add(labelTel);
	   panel2.add(textFieldTel);
	   
	   panel3.setLayout(new FlowLayout(FlowLayout.LEFT));
	   panel3.add(textFieldEmail);
	   panel3.add(buttonSend);
	   
	   panel4.setLayout(new FlowLayout(FlowLayout.LEFT));
	   panel4.add(textFieldAddress);
	   
	   // panelWestBot
	   panelWestBot.setLayout(new FlowLayout());
	   panelWestBot.add(buttonImg);
   
	   // panelCenter
	   panelCenter.setBorder(new TitledBorder(new BevelBorder(BevelBorder.RAISED), "회원 리스트"));
	   panelCenter.setLayout(new BorderLayout());
	   panelCenter.add("North", panel5);
	   panelCenter.add("Center", scrollPane);
	      
	   panel5.setLayout(new FlowLayout(FlowLayout.LEFT));
	   panel5.add(labelMName);
	   panel5.add(textFieldMName);
	   panel5.add(buttonSearchPart);
	   panel5.add(buttonSearchAll);   
	   
//	   defaultTableModel.setValueAt("Test", 2, 2);
   }

   private void start() {
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      
      button1.addActionListener(this);   //등록
      button2.addActionListener(this);   //수정
      button3.addActionListener(this);   //삭제
      button4.addActionListener(this);   //초기화
      buttonSearchPart.addActionListener(this);   //검색
      buttonSearchAll.addActionListener(this);   //전체
      
   }  
	@Override
	public void actionPerformed(ActionEvent e) {

		   MemberDTO dto = new MemberDTO();
		   MemberDAO dao = new MemberDAO();
		   
		   if(e.getSource() == buttonSend) {
			   
		   }	   
		   // Left 하단 버튼 클릭 이벤트 작동 처리
		   if(e.getSource() == button1) {
//			   System.out.println("등록버튼 동작");
				if(textFieldName.getText().trim().length()==0 || textFieldName.getText().trim().equals("아이디")) {
					JOptionPane.showMessageDialog(null, "이름을 입력해 주세요.", "아이디 입력", JOptionPane.WARNING_MESSAGE);
					textFieldName.grabFocus();
					return;
				}
				if(textFieldAge.getText().trim().length()==0) {
					JOptionPane.showMessageDialog(null, "나이를 입력해 주세요.", "비밀번호 입력", JOptionPane.WARNING_MESSAGE);
					textFieldAge.grabFocus();
					return;
				}
				if(textFieldTel.getText().trim().length()==0) {
					JOptionPane.showMessageDialog(null, "전화번호를 입력해 주세요.", "전화번호 입력", JOptionPane.WARNING_MESSAGE);
					textFieldTel.grabFocus();
					return;
				}
				if(textFieldEmail.getText().trim().length()==0 || textFieldEmail.getText().trim().equals("이름")) {
					JOptionPane.showMessageDialog(null, "이메일을 입력해 주세요.", "이름 입력", JOptionPane.WARNING_MESSAGE);
					textFieldEmail.grabFocus();
					return;
				}
				if(textFieldAddress.getText().trim().length()==0 || textFieldAddress.getText().trim().equals("주소")) {
					JOptionPane.showMessageDialog(null, "주소를 입력해 주세요.", "주소 입력", JOptionPane.WARNING_MESSAGE);
					textFieldAddress.grabFocus();
					return;
				}
			   dto.setm_name(textFieldName.getText()); 
				if(radioButton1.isSelected()) {
					dto.setm_gender(radioButton1.getText());
				} else {
					dto.setm_gender(radioButton2.getText());
				}
			   dto.setm_age(Integer.parseInt(textFieldAge.getText()));
			   dto.setm_tel(Integer.parseInt(textFieldTel.getText()));
			   dto.setm_Email(textFieldEmail.getText());
			   dto.setm_address(textFieldAddress.getText());
			   
				int result = dao.insertArticle(dto);
				if(result > 0) {
					JOptionPane.showMessageDialog(null, textFieldName.getText() + "님 데이터가 등록되었습니다");
				}
				else {
					System.out.println("result값 미생성");
				}
		   } else if(e.getSource() == button2) {
			   System.out.println("update test");
			   int age = Integer.parseInt(textFieldAge.getText());
			   String gender = "";
				if(radioButton1.isSelected()) {
					gender = "남성";
				} else {
					gender = "여성";
				}
			   int tel = Integer.parseInt(textFieldTel.getText());
			   String email = textFieldEmail.getText();
			   String address = textFieldAddress.getText();
			   String name = textFieldName.getText();
			   
			   dto.setm_age(age);
			   dto.setm_gender(gender);
			   dto.setm_tel(tel);
			   dto.setm_Email(email);
			   dto.setm_address(address);
			   dto.setm_name(name);
			   int result = dao.updateArticle(dto);
			   
				if(result > 0) {
					JOptionPane.showMessageDialog(null, textFieldName.getText() + "님 데이터가 수정되었습니다");
				}
				else {
					System.out.println("result값 미생성");
				}
			   
		   } 
		   if(e.getSource() == button3) {
			   String name = textFieldName.getText();
//			   System.out.println("delete test");			   
			   			   
			   int result = dao.deleteArticle(name);
			   
			   if(result > 0) {
//				   System.out.println("delete Test");
				   JOptionPane.showMessageDialog(null, name + "님 데이터가 삭제되었습니다");
			   } else {
				   JOptionPane.showMessageDialog(null, "삭제할 이름을 입력해주세요");
			   }
		   } else if(e.getSource() == button4) {
			   textFieldName.setText("");
			   textFieldAge.setText("");
			   textFieldTel.setText("");
			   textFieldEmail.setText("");
			   textFieldAddress.setText("");
		   }
		   
		   // Right 상단 버튼 클릭 이벤트 작동 처리
		   if(e.getSource() == buttonSearchPart) {
//			   System.out.println("이름검색버튼 동작");
			   String inputName = textFieldMName.getText();
			   if(inputName.equals("")) {
//				   textArea.setText("");
				   JOptionPane.showMessageDialog(null, "이름을 입력하세요");
			   }
			   textArea.setText("번호      이름        성별       나이       "
			   		+ "전화번호\t         이메일\t\t       주소\n");
			   String name = textFieldMName.getText();
				List<MemberDTO> list = dao.selectPart(name);
				for(int i=0; i<list.size(); i++) {
					dto = list.get(i);
					output(dto);
				}	
	       
		   } 
		   if(e.getSource() == buttonSearchAll) {
			   
			   textArea.setText("");
			   textArea.setText("번호      이름        성별       나이       "
			   		+ "전화번호\t         이메일\t\t       주소\n");
		         
		       List<MemberDTO> list = dao.selectList();
		       for(int i=0; i<list.size(); i++) {
		          dto = list.get(i);
		          output(dto);
		       }
		   }		
	}
	
   private void output(MemberDTO dto) {
		
		   String str = dto.getm_number() + "         "
				   		+ dto.getm_name() + "        "
				   		+ dto.getm_gender() + "      "
				   		+ dto.getm_age() + "     "
				   		+ dto.getm_tel() +"\t  "
				   		+ dto.getm_Email() + "\t  "
				   		+ dto.getm_address() + "\n";
		   
		   		textArea.append(str);		
	}
}